let currentIndex = 0;
const items = document.querySelectorAll('.carousel-item');
const totalItems = items.length;

function showSlide(index) {
    items.forEach(item => item.classList.remove('active'));
    items[index].classList.add('active');
}

function nextSlide() {
    currentIndex = (currentIndex + 1) % totalItems;
    showSlide(currentIndex);
}

function startCarousel() {
    setInterval(nextSlide, 3000); // Troca o slide a cada 3 segundos
}

document.addEventListener('DOMContentLoaded', startCarousel);